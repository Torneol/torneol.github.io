console.log("A Loja do Impossível está no ar! 🚀");
